//Tommy Suen

//Usual Libraries
#include <iostream>
#include <cstdlib>
#include <fstream>

//Usual namespace
using namespace std;

int main()
{
	//Open input file 
	ifstream fin("BookBorrow.txt");
	
	if(!fin)
	{
		cout << "There is no input file..." << endl;
		system("PAUSE");
		return EXIT_FAILURE;
	}
	
	//Constants for status and book comparison input
	const string STUDENT = "student", ALUMNI = "alumni", STAFF = "staff";
	const string BOOK = "book", JOURNAL = "journal", ELECTRONIC = "ebook";
	
	string status = "", book_type = """";
	
	//Welcome message!!
	cout << "Welcome! My program tells you how long you may borrow a book."; 
	cout << endl;
	
	while(fin >> status and fin >> book_type)
	{
		/*Asks the user about their status and what type of book they are borrowing
		cout << "Are a 'student', 'alumni', or 'staff'? ";
		cin >> status;
		cout << "Would you like to borrow a 'book', 'journal', or an 'ebook'? ";
		cin >> book_type;
		*/
		
		//Check for the amount of books that the person may borrow
		cout << "You can borrow ";
		if (status == ALUMNI)
			if(book_type == BOOK)
				cout << "20 books for two weeks.";
			else 
				cout << "NOTHING.";
		else
			cout << "an unlimited amount of these books for";
		
		//If the person is not an alumni (one of the two above special cases),
		//Then, go further check for how long they can borrow the book
		if(status != ALUMNI)
			if(status == STAFF)
				if (book_type == BOOK)
					cout << " the entire term.";
				else if(book_type == ELECTRONIC)
					cout << "ever.";
				else
					cout << " for two weeks.";
		else 
			cout << " for two weeks.";
		cout << endl;
	}
	
	//End message
	cout << "Thanks for using my program! Please come back again!!" << endl;
	system("PAUSE");
	return EXIT_SUCCESS;
}

/*

*/
