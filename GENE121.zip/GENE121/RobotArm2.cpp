//Tommy Suen

//Usual Libraries
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <fstream>

//Usual Namespace
using namespace std;

int main()
{
	//Open input file 
	ifstream fin("A3Actual.txt");
	
	//If there is no input file, exit
	if(!fin)
	{
		cout << "There is no input file..." << endl;
		system("PAUSE");
		return EXIT_FAILURE;
	}
	
	//Declare and instantiate arm length, x and y values, 
	//And succes and failure counters
	const double TOL = 1e-1;
	double arm_length = 0, x = 0, y = 0;
	int success = 0, failure = 0;
	
	//Read in the arm_length first and only once
	if(fin >> arm_length);
	//If you can still read in two values
	while(fin >> x and fin >> y)
	{
	    //Check whether those two values are a success or not
	    if(fabs(arm_length - sqrt(pow(x, 2) + pow(y, 2))) < TOL)
	       success++;
	    else 
	       failure++;
    }
    
    //Print final total and end program
    cout << "SUCCESSES: " << success << endl;
    cout << "FAILURES: " << failure << endl;
	system("PAUSE");
	return EXIT_SUCCESS;
}

/*

*/
