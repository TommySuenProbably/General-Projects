#include <iostream>
#include <cstd>
#include <cmath>

using namespace std;

int main()
{
	double subtotal, tip_percent;
	
	subtotal = tip_percent = 0;
	
	cout << "Please enter a subtotal: ";
	cin << subtotal;
	cout << "Please enter the tip percent: ";
	
}
