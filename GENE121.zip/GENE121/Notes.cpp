/*PERIODIC POLLING: FLOW CHART
START
Step 1 - Does the door key NOT work? (loop if key does not work)
Step 2 - Wait one day (loop)
FALSE --> Move to the new office
END

Similar to periodic polling in the EV3 except that it polls per hertz

Ex.1 Driving towards the wall, display distance every second
START
Step 1 - Configure Sensors
Step 2 - Motors on (25%)
Step 3 - Far from wall (loop)
TRUE --> Output time
FALSE --> Turn off motors (0%)
*/

// Robot C is a teaching language and recognizes uppercase and lowercase

task main ()
{
    const int speed = 25;
    const double leeway = 50;
    SensorType[S1] = sensorEV3_Ultrasonic;
    
    motor[motorA] = motor [motorD] = speed;
    
    while(SensorValue[S2] > leeway])
    {
        eraseDisplay();
        displayBigString(2,"Distance = %.2dcm", SensorValue[S2]]);
        wait1Msec(1000);
    }
    
    motor[motorA] = motor [motorD] = 0;
}

/*
After you declare a type, remember to wait (50 msecs) before configuring
the mode for a sensor.
FUNCTIONS:
** long degrees = getGyroDegrees[S1]; **
** long degrees = getGyroDegrees[S1]; **
To reorient, resetGyro();

Ex.2 Rotate 90 degrees, unless we hit something
START
Step 1 - Configure sensro
Step 2 - motors on
Step 3 - Loop while angle < 90
*/

task main ()
{
    SensorType[S3] = sensorEV_Touch;
    SensorType[S1] = sensorEV_Gyro;
    wait1Msec(50);
    SensorMode [S1] = modeEV3Gyro_RateAndAngle;
    wait1Msec(50)
    
    resetGyro(S1);
    
    motor[motorA] = -25
    motor[motorD] = 25;
    
    while(getGyroDegrees < 90 && SensorValue[S3] == 0)
    {}
    
    motor[motorA] = motor[motorD] = 0;
}
