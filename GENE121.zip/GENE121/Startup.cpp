//Tommy Suen

//Usual Libraries
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <fstream>

//Usual Namespace
using namespace std;

int main()
{
	
	system("PAUSE");
	return EXIT_SUCCESS;
}

/*

*/
